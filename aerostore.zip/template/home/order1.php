<html>
<head>
<title>AEROSTORE - Top Up Games Aman, Murah, & Terpercaya</title>
<link rel="shortcut icon" href="aero1.ico" type="image/x-icon">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="AEROSTORE Tempat Top Up Games Yang Aman, Murah, dan Terpercaya Sejak 2017 Menyediakan Layanan Top Up Diamond Mobile Legends Dan UC PUBG Mobile Serta Jasa Joki Mobile Legends .">
<meta name="robots" content="index,nofollow">
<meta name="author" content="AEROSTORE">
<meta name="keywords" content="diamond ml murah, top up ml murah, diamond mobile legend murah, AEROSTORE">
<meta name="language" content="ID">
<meta name="coverage" content="Worldwide">
<link rel="stylesheet" href="assets\vendor\fontawesome\css\all.css">
<link rel="stylesheet" href="assets\vendor\bootstrap\css\bootstrap.min.css">
<script src="assets\js\jquery-3.5.1.min.js"></script>
<script src="assets\vendor\bootstrap\js\bootstrap.bundle.min.js"></script>
<script src="assets\vendor\alertifyjs\alertify.min.js"></script>
<link rel="stylesheet" href="assets\vendor\alertifyjs\css\alertify.min.css">
<link rel="stylesheet" href="assets\vendor\alertifyjs\css\themes\bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets\vendor\DataTables\DataTables-1.10.22\css\dataTables.bootstrap4.min.css?x">
<script type="text/javascript" src="assets\vendor\DataTables\DataTables-1.10.22\js\jquery.dataTables.min.js?x">
    </script>
<script type="text/javascript" src="assets\vendor\DataTables\DataTables-1.10.22\js\dataTables.bootstrap4.min.js?x">
    </script>
<link rel="stylesheet" href="assets\css\style.css?v=1641098465">
<script src="https://www.google.com/recaptcha/api.js" async="" defer=""></script>
</head>
<header>
<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-custom shadow-sm p-3 mb-5 bg-white">
<div class="container">
	<a class="navbar-brand" href="index.php"><img src="aero1.png" width="50px"></a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	<i class="fas fa-bars color-primary" style="font-size: 26px;"></i>
	</button>
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<div class="mr-auto"></div>
		<ul class="navbar-nav">
			<li class="nav-item">
				<li class="nav-item">
					<a class="nav-link active" href="index.php"><i class="fas fa-home"></i> Home</a>
				</li>
				
			</ul>
		</div>
	</div>
	</nav>
	</header>
	<div class="preloader">
		<div class="loading">
			<img src="assets\images\preloader.gif" width="100"></div>
	</div>
	<script>
$(document).ready(function() {
    $(".preloader").fadeOut();
})
	</script>
	<br>
	<body class="d-flex flex-column min-vh-100">
	<br>
	<br>
	<br>
	<br>
	<div class="container">
		<div class="row mt-2" style="margin:0px">
			<div id="slider-img" class="carousel slide" data-ride="carousel">
				<ol class="carousel-indicators">
					<li data-target="#slider-img" data-slide-to="0" class="active"></li>
				</ol>
				<div class="carousel-inner" style="border-radius: 5px;">
					<div class="carousel-item active">
						<img src="aero2.png" class="d-block w-100"></div>
				</div>
				<a class="carousel-control-prev" href="#slider-img" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#slider-img" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
		<div class="col-12 mb-3 mt-4">
			<center>
			<span class="p-2" style="font-weight: 700; font-size: 20px; border-radius: 4px; color: #001439"></span>
			</center>
		</div>
		
		<div class="container">
        <div class="row mt-2" style="margin:0px">
            <div class="col-md-12 col-sm-12 col-lg-4">
                <div class="text-center text-md-left mb-2">
                    <img src="mlfast.png" class="img-responsive rounded mb-2" width="200px" height="200px">
                </div>
                <h5>Mobile Legends</h5>
                <span class="strip-primary"></span>
                <p class="mt-4 pr-4"><h6>Proses 1-5 Menit</h6><center><font size="4" color="#00BFFF"><b>Open 24 Jam</b></font></center>
<font size="4" color="black"><b> Cara Order : </b>
<br>
1. Masukan ID (SERVER) <br>
2. Pilih nominal Diamond <br>
3. Pilih Metode Pembayaran<br>
4. Masukan Nomor WhatsApp Kamu<br>
5. Klik Beli Sekarang & Lakukan Pembayaran<br>
6. Tunggu 1 - 5 menit (Jika Event Max 6 Jam) Diamond Akan Masuk Otomatis Di Akun Anda</font>
<br>
<br>
<center><font size="4" color="#00BFFF"><b>Estimasi Proses Otomatis 1 - 5 menit</b></font></center>
<!DOCTYPE html>
<html>
<head>
<title> TEKS BERJALAN </title>
</head>
<body>
<marquee><font size="4" color="#00BFFF"><b>Jika Event Maximal 360 Menit</b></font></marquee>
<body>
<html>
            </html></body></body></html></div>
            <div class="col-md-12 col-sm-12 col-lg-8">
				<form>
                   <div class="row">
                    	                        
<div class="col-12 mb-3">
	<div class="card">
		<div class="card-body">
			<div class="text-white text-center position-absolute circle-primary">1</div>
			<h5 style="margin-left: 40px;">Lengkapi data</h5>
			<hr>
			<div class="form-row mt-4">
				<div class="col">
					<input type="number" class="form-control" id="userid" name="data" placeholder="Masukan UserID" required="">
				</div>
				<div class="col">
					<input type="number" class="form-control" id="zoneid" name="zoneid" placeholder="Masukan ServerID" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength="5" required="">
				</div>
			</div>
			<div class="mt-3">
				
			</div>
		</div>
	</div>
</div>
    <div id="note"></div>
    <div class="col-12 mb-3">
    <div class="card">
            <div class="card-body">
            <div class="text-white text-center position-absolute circle-primary">2</div>
            <h5 style="margin-left: 40px;">Pilih nominal</h5>
                <hr><div class="mt-4">
                    <div class="panel-topup">
                        <input type="radio" id="service0" name="service" value="423"><label id="label_service0" for="service0"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket423">86 Diamonds</span> <br>Rp <span id="harga423">20.650</span></label>
                        <input type="radio" id="service1" name="service" value="424"><label id="label_service1" for="service1"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket424">172 Diamonds</span> <br>Rp <span id="harga424">41.300</span></label>
                        <input type="radio" id="service2" name="service" value="425"><label id="label_service2" for="service2"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket425">257 Diamonds</span> <br>Rp <span id="harga425">61.950</span></label>
                        <input type="radio" id="service3" name="service" value="426"><label id="label_service3" for="service3"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket426">344 Diamonds</span> <br>Rp <span id="harga426">82.600</span></label>
                        <input type="radio" id="service4" name="service" value="427"><label id="label_service4" for="service4"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket427">429 Diamonds</span> <br>Rp <span id="harga427">103.250</span></label>
                        <input type="radio" id="service5" name="service" value="428"><label id="label_service5" for="service5"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket428">514 Diamonds</span> <br>Rp <span id="harga428">123.900</span></label>
                        <input type="radio" id="service6" name="service" value="431"><label id="label_service6" for="service6"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket431">706 Diamonds</span> <br>Rp <span id="harga431">165.250</span></label>
                        <input type="radio" id="service7" name="service" value="432"><label id="label_service7" for="service7"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket432">878 Diamonds</span> <br>Rp <span id="harga432">206.500</span></label>
                        <input type="radio" id="service8" name="service" value="433"><label id="label_service8" for="service8"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket433">963 Diamonds</span> <br>Rp <span id="harga433">227.150</span></label>
                        <input type="radio" id="service9" name="service" value="434"><label id="label_service9" for="service9"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket434">1412 Diamonds</span> <br>Rp <span id="harga434">330.400</span></label>
                        <input type="radio" id="service10" name="service" value="435"><label id="label_service10" for="service10"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket435">2195 Diamonds</span> <br>Rp <span id="harga435">491.175</span></label>
                        <input type="radio" id="service11" name="service" value="436"><label id="label_service11" for="service11"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket436">3688 Diamonds</span> <br>Rp <span id="harga436">817.150</span></label>
                        <input type="radio" id="service12" name="service" value="437"><label id="label_service12" for="service12"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket437">4394 Diamonds</span><br>Rp <span id="harga437">982.350</span></label>
                        <input type="radio" id="service13" name="service" value="438"><label id="label_service13" for="service13"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket438">5532 Diamonds</span> <br>Rp <span id="harga438">1.227.200</span></label>
                        <input type="radio" id="service14" name="service" value="439"><label id="label_service14" for="service14"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket439">6235 Diamonds</span> <br>Rp <span id="harga439">1.392.400</span></label>
                        <input type="radio" id="service15" name="service" value="440"><label id="label_service15" for="service15"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket440">7727 Diamonds</span> <br>Rp <span id="harga440">1.718.375</span></label>
                        <input type="radio" id="service16" name="service" value="441"><label id="label_service16" for="service16"><img style="margin-right: 3px !important;" height="18px" src="assets\images\1615286239.png"><span id="paket441">9288 Diamonds</span> <br>Rp <span id="harga441">2.044.000</span></label>                                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 mb-3">
		<div class="card">
			<div class="card-body">
				<div class="text-white text-center position-absolute circle-primary">3</div>
				<h5 style="margin-left: 40px;">Pilih Metode Pembayaran</h5>
				<hr>
				<h6 style="margin-left: 20px;">Transfer Bank</h6>
				<div class="form-row mt-4">
					<div class="panel-topup">
					<input type="radio" id="tf-bni" name="tf" value="2"><label id="bni" for="tf-bni"><img style="margin-right: 3px !important;" height="50px" src="assets\images\bayar\bni.png"></label>
					<input type="radio" id="tf-bri" name="tf" value="1"><label id="bri" for="tf-bri"><img style="margin-right: 3px !important;" height="50px" src="assets\images\bayar\bri.png"></label>
					<input type="radio" id="tf-mandiri" name="tf" value="3"><label id="mandiri" for="tf-mandiri"><img style="margin-right: 3px !important;" height="50px" src="assets\images\bayar\mandiri.png"></label>
				</div>
				<div class="mt-4">
					<h6 style="margin-left: 20px;">E - Wallet</h6>
					<input type="radio" id="tf-dana" name="tf" value="6"><label for="tf-dana"><img style="margin-right: 3px !important;" height="50px" src="assets\images\bayar\dana.png"></label>
					<input type="radio" id="tf-gopay" name="tf" value="5"><label for="tf-gopay"><img style="margin-right: 3px !important;" height="50px" src="assets\images\bayar\gopay.png"></label>
					<input type="radio" id="tf-ovo" name="tf" value="4"><label id="ovo" for="tf-ovo"><img style="margin-right: 3px !important;" height="50px" src="assets\images\bayar\ovo.png"></label>
					<!-- <input type="radio" id="tf-shopee" name="tw-wallet" value="423"><label onclick="ganti('shopee')" id="shopee" for="tf-ovo"><img style="margin-right: 3px !important;" height="50px" src="assets\images\bayar\shopee.png"></label> -->
				</div>
		</div>
	</div>

	<div class="col-12 mb-3">
	<div class="card">
		<div class="card-body">
			<div class="text-white text-center position-absolute circle-primary">4</div>
			<h5 style="margin-left: 40px;">Nomor Telp (WhatsApp)</h5>
			<hr>
			<div class="form-row mt-4">
				<div class="col">
					<input type="number" id="no_hp" class="form-control" name="no_hp" placeholder="6281xxxx" required="">
				</div>
			</div>
			<div class="mt-4">
				<div class="col">
					<input type="text" id="nama" class="form-control" name="nama" placeholder="Nama User" required="">
				</div>
			</div>
	</div>
	</div>

</div>
<div class="col-12 mb-3"></div>
    <div class="col-12 mb-3">
		 <button type="button" id="btn-submit"><b>BELI SEKARANG</b></button> 
       
    </div>
                        <div id="ordermodal" class="modal fade" tabindex="-1" role="dialog">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <div id="orderdetail"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
		
	</div>
	</body>
	
	<script>
		var demoImage = '1645470336.png';
	</script>
	<script src="promobox.js"></script>
	
	<div class="container container-1440">
    <div class="px-lg-3 pt-3">
      <div class="row">
        <div class="col-12">
          <div class="caption-group caption-group caption-group-lg-left">
            <div class="sub-caption">Dukungan Pelanggan</div>

            <div class="caption">
              <h2>Hubungi kami</h2>
            </div>
          </div>

          <div class="home-cs-container mt-3">
            <a class="home-cs-card" href="http://wa.me/6282234963134" target="_blank">
              <div class="cs-image">
                  <img alt="" src="wa.svg">
              </div>
              <div class="cs-caption"></div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
	
	
	<script>var demoImage = '';</script>
	<script src="assets\js\promobox.js"></script>
	<br>
	<footer class="footer mt-auto">
	<div class="container pt-md-3 pb-md-3 text-left text-md-left">
		<div class="row">
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-gamepad mb-2"></i></h1>
				<h5>PILIH GAME</h5>
				 Tersedia beberapa game pilihan seperti Mobile Legends dan PUBG Mobile.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-hand-pointer mb-2"></i></h1>
				<h5>PILIH NOMINAL</h5>
				 Pilih nominal topup game yang kamu pilih yang tersedia pada form order web.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-money-bill-wave mb-2"></i></h1>
				<h5>LAKUKAN PEMBAYARAN</h5>
				 Tersedia berbagai metode pembayaran diantaranya Alfamart, Bank BCA, Bank Mandiri, Bank BNI, Bank Bri, DANA, OVO, Gopay, Shopee Pay, Link Aja, dll.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-gift mb-2"></i></h1>
				<h5>TOPUP BERHASIL</h5>
				 Topup akan diproses segera setelah pembayaran & konfirmasi pembayaran sudah dilakukan
			</div>
		</div>
	</div>
	<div class="footer-copyright py-3">
		<div class="container mt-2">
			<div class="row">
				
				
				<div class="col-lg-12 text-center text-md-left">
					<hr>
					<div class="">
						 © 2022 <a href="#">AEROSTORE</a>  <a href="terms.html"></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	</footer>
	<a href="https://www.instagram.com/aero_store1/" class="btn-ig-float shadow-sm" target="_blank"><i class="fab fa-instagram" style="margin-top: 9px;"></i></a>
	<a href="https://api.whatsapp.com/send?phone=6282234963134" class="btn-call-float shadow-sm" target="_blank"><i class="fab fa-whatsapp" style="margin-top: 9px;"></i></a>
	<a href="#" id="btn-gotop" onclick="topFunction()"><i class="fas fa-angle-up mt-1"></i></a>
	<script>
mybutton = document.getElementById("btn-gotop");
window.onscroll = function() {
    scrollFunction()
};
function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
	</script>
<?php include "ajax.php"; ?>
	</html>