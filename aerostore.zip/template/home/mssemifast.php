<html>
<head>
<title>LonaStoreID - Top Up Games Aman, Murah, & Terpercaya</title>
<link rel="shortcut icon" href="logolona.jpeg" type="image/x-icon">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="LonaStoreID Tempat Top Up Games Yang Aman, Murah, dan Terpercaya Sejak 2017 Menyediakan Layanan Top Up Diamond Mobile Legends Dan UC PUBG Mobile Serta Jasa Joki Mobile Legends .">
<meta name="robots" content="index,nofollow">
<meta name="author" content="LonaStoreID">
<meta name="keywords" content="diamond ml murah, top up ml murah, diamond mobile legend murah, LonaStoreID">
<meta name="language" content="ID">
<meta name="coverage" content="Worldwide">
<link rel="stylesheet" href="assets\vendor\fontawesome\css\all.css">
<link rel="stylesheet" href="assets\vendor\bootstrap\css\bootstrap.min.css">
<script src="assets\js\jquery-3.5.1.min.js"></script>
<script src="assets\vendor\bootstrap\js\bootstrap.bundle.min.js"></script>
<script src="assets\vendor\alertifyjs\alertify.min.js"></script>
<link rel="stylesheet" href="assets\vendor\alertifyjs\css\alertify.min.css">
<link rel="stylesheet" href="assets\vendor\alertifyjs\css\themes\bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets\vendor\DataTables\DataTables-1.10.22\css\dataTables.bootstrap4.min.css?x">
<script type="text/javascript" src="assets\vendor\DataTables\DataTables-1.10.22\js\jquery.dataTables.min.js?x">
    </script>
<script type="text/javascript" src="assets\vendor\DataTables\DataTables-1.10.22\js\dataTables.bootstrap4.min.js?x">
    </script>
<link rel="stylesheet" href="assets\css\style.css?v=1641098465">
<script src="https://www.google.com/recaptcha/api.js" async="" defer=""></script>
</head>
<header>
<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-custom shadow-sm p-3 mb-5 bg-white">
<div class="container">
	<a class="navbar-brand" href="index.htm"><img src="logolona.jpeg" width="140px"></a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	<i class="fas fa-bars color-primary" style="font-size: 26px;"></i>
	</button>
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<div class="mr-auto"></div>
		<ul class="navbar-nav">
			<li class="nav-item">
				<li class="nav-item">
					<a class="nav-link active" href="index.htm"><i class="fas fa-home"></i> Home</a>
				</li>
				
			</ul>
		</div>
	</div>
	</nav>
	</header>
	<div class="preloader">
		<div class="loading">
			<img src="assets\images\preloader.gif" width="100"></div>
	</div>
<script>
$(document).ready(function() {
    $(".preloader").fadeOut();
})
</script>
<br>
<body class="d-flex flex-column min-vh-100">
    <br><br><br><br>
    <div class="container">
        <div class="row mt-2" style="margin:0px">
            <div class="col-md-12 col-sm-12 col-lg-4">
                <div class="text-center text-md-left mb-2">
                    <img src="lonamlsemi.jpeg" class="img-responsive rounded mb-2" width="200px" height="200px">
                </div>
                <h5>Mobile Legends</h5>
                <span class="strip-primary"></span>
                <p class="mt-4 pr-4"><h6>Proses 15-60 Menit (Buka 24 Jam)</h6> <span class="strip-primary"></span>
                <p class="mt-4 pr-4"><h6>Paket Kilat</h6><center><font size="4" color="#587cc7"><b>Layanan Aktif 24 Jam</b></font></center>
<ol><li>Masukkan <b>ID (SERVER)</b></li>
<li>Pilih <b>Nominal Diamond</b></li>
<li>Pilih Metode Pembayaran</li>
<li>Masukan Nomor <b>WhatsApp </b>Kamu</li>
<li>Klik <b>Beli Sekarang</b> & Lakukan <b>Pembayaran</b></li>
<li>Tunggu 15-60 Menit Diamond Akan Masuk Otomatis Di Akun Anda. (Jika Event Maksimal 6 Jam)</li></ol>

<center><font size="4" color="#f33300"><b>Estimasi Proses Otomatis 15 - 60 Menit</b></font></center>
<!DOCTYPE html>
<html>
<head>
<title> TEKS BERJALAN </title>
</head>
<body>
<marquee><font size="4" color="#f33300"><b>Jika Event Maximal 360 Menit</b></font></marquee>
<body>
<html>
<hr><center><strong>
<font size="4" color="#f33300">Mengalami Kendala Top Up? </font>
<br>
<br>
 <p>Hubungi Whatsapp Kami</p>
 <br>

</strong></center><hr>
            </html></body></body></html></div>
            <div class="col-md-12 col-sm-12 col-lg-8">
			
			<form action="confirm.php" method="POST">
			
               
                    <div class="row">
                    	                        
<div class="col-12 mb-3">
	<div class="card">
		<div class="card-body">
		<div class="pt-1 text-white text-center position-absolute circle-primary">1</div>
		<h5 class="ml-5 mt-1">Lengkapi Data</h5>
		
			<input name="layanan" type="hidden" value="Mobile Legends Semi Fast"/>
			<input name="nickname" type="hidden" value=""/>
			<input name="sisauc" type="hidden" value="0"/>
		
			<div class="form-row mt-4">
				<div class="col">
					<input type="number" class="form-control" name="data" placeholder="Masukan UserID" required="">
				</div>
				<div class="col">
					<input type="number" class="form-control" name="zoneid" placeholder="Masukan ServerID" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength="5" required="">
				</div>
			</div>
			<div class="mt-3">
				<button type="button" class="btn btn-original btn-sm" data-toggle="modal" data-target="#exampleModal">Petunjuk</button>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="pt-2 pr-3">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<img class="img-fluid" src="assets\images\1603588464.png">
				</div>
			</div>
		</div>
	</div>
</div>
                        <div id="note"></div>
                        <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    
                                <div class="pt-1 text-white text-center position-absolute circle-primary">2</div>
                                    <h5 class="ml-5 mt-1">Pilih Nominal</h5>
                                    <div class="mt-4">
                                        <div class="panel-topup">
                                            <input type="radio" id="service0" name="service" value="113 Diamonds Rp 35.000"><label for="service0">113 Diamonds<br>Rp 35.000</label>
											<input type="radio" id="service1" name="service" value="168 Diamonds Rp 43.000"><label for="service1">168 Diamonds<br>Rp 43.000</label>
											<input type="radio" id="service2" name="service" value="226 Diamonds Rp 60.000"><label for="service2">226 Diamonds<br>Rp 60.000</label>
											<input type="radio" id="service3" name="service" value="460 Diamonds Rp 135.000"><label for="service3">460 Diamonds<br>Rp 135.000</label>
											<input type="radio" id="service4" name="service" value="1427 Diamonds Rp 320.000"><label for="service4">1427 Diamonds<br>Rp 320.000</label>
											<input type="radio" id="service5" name="service" value="2398 Diamonds Rp 530.000"><label for="service5">2398 Diamonds<br>Rp 530.000</label>
											<input type="radio" id="service6" name="service" value="3596 Diamonds Rp 760.000"><label for="service6">3596 Diamonds<br>Rp 760.000</label>
											<input type="radio" id="service7" name="service" value="4056 Diamonds Rp 837.000"><label for="service7">4056 Diamonds<br>Rp 837.000</label>
											<input type="radio" id="service8" name="service" value="6038 Diamonds Rp1.350.000"><label for="service8">6038 Diamonds<br>Rp1.350.000</label>
											<input type="radio" id="service9" name="service" value="7465 Diamonds Rp1.520.000"><label for="service9">7465 Diamonds<br>Rp1.520.000</label>
											
											<input type="radio" id="service10" name="service" value="12076 Diamonds Rp2.550.000"><label for="service10">12076 Diamonds<br>Rp2.550.000</label>
											<input type="radio" id="service11" name="service" value="18114 Diamonds Rp3.760.000"><label for="service11">18114 Diamonds<br>Rp3.760.000</label>
											<input type="radio" id="service12" name="service" value="24152 Diamonds Rp5.000.000"><label for="service12">24152 Diamonds<br>Rp5.000.000</label>
											<input type="radio" id="service13" name="service" value="30190 Diamonds Rp6.300.000"><label for="service13">30190 Diamonds<br>Rp6.300.000</label>
											
											
											<input type="radio" id="service14" name="service" value="Starlight Rp 135.000"><label for="service14">Starlight<br>Rp 135.000</label>
											<input type="radio" id="service15" name="service" value="Twilight Rp 135.000"><label for="service15">Twilight<br>Rp 135.000</label>
											<input type="radio" id="service16" name="service" value="Starlight+ Rp 290.000"><label for="service16">Starlight+<br>Rp 290.000</label>
											
	 
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <div class="pt-1 text-white text-center position-absolute circle-primary">3</div>
                                    <h5 class="ml-5 mt-1">Pilih Metode Pembayaran</h5>
                                    <div class="mt-4">
                                        <div class="methods">
                                            <input class="mtdbtn" type="radio" id="method0" name="method" value="BCA 8305432861 a/n YULIANA">
    <label class="mtdlabel" for="method0"><img src="bca.png" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="TRANSFER_BANK_BCA"></span>
        </p>
    </label><input class="mtdbtn" type="radio" id="method1" name="method" value="BSI 1136092548 a/n YULIANA">
    <label class="mtdlabel" for="method1"><img src="bsi.jpg" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="TRANSFER_BANK_BSI"></span>
        </p>
    </label><input class="mtdbtn" type="radio" id="method2" name="method" value="DANA 082240798083 a/n YULIANA">
    <label class="mtdlabel" for="method2"><img src="dana.png" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="TRANSFER_BANK_BNI"></span>
        </p>
    </label><input class="mtdbtn" type="radio" id="method3" name="method" value="LINK AJA 082240798083 a/n YULIANA">
    <label class="mtdlabel" for="method3"><img src="linkaja.png" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="QRIS"></span>
        </p>
    </label>                                   </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                <div class="pt-1 text-white text-center position-absolute circle-primary">4</div>
                                    <h5 class="ml-5 mt-1">Masukan Nomor Whatsapp</h5>
                                    <div class="mt-4">
                                        <input type="number" class="form-control" name="nohp" placeholder="08xxxxxxxxx" required="">
                                    </div>
                                </div>
                            </div>
							<div class="card">
                                <div class="card-body">
                                <div class="pt-1 text-white text-center position-absolute circle-primary">5</div>
                                    
                                    <div class="mt-4">
									    <center>
                                        <input type="submit" value="TEKAN ORDER SEKARANG" >
										</center>
                                    </div>
                                </div>
                            </div>
                        </div>
						
						
                        
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

<br>
<footer class="footer mt-auto">
	<div class="container pt-md-3 pb-md-3 text-left text-md-left">
		<div class="row">
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-gamepad mb-2"></i></h1>
				<h5>PILIH GAME</h5>
				 Tersedia beberapa game pilihan seperti Mobile Legends dan PUBG Mobile.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-hand-pointer mb-2"></i></h1>
				<h5>PILIH NOMINAL</h5>
				 Pilih nominal topup game yang kamu pilih yang tersedia pada form order web.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-money-bill-wave mb-2"></i></h1>
				<h5>LAKUKAN PEMBAYARAN</h5>
				 Tersedia berbagai metode pembayaran diantaranya Bank BCA, Bank BSI, DANA & LINK AJA
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-gift mb-2"></i></h1>
				<h5>TOPUP BERHASIL</h5>
				 Topup akan diproses segera setelah pembayaran & konfirmasi pembayaran sudah dilakukan
			</div>
		</div>
	</div>
	<div class="footer-copyright py-3">
		<div class="container mt-2">
			<div class="row">
				<div class="col-lg-6 mb-3">
					<h4 class="mt-2 mb-3">LonaStoreID</h4>
					 LonaStoreID Adalah Tempat Top Up Games Yang Aman, Murah, dan Terpercaya. LonaStoreID Menyediakan Layanan Top Up Games seperti Diamond Mobile Legends Dan UC PUBG Mobile. Untuk Mempermudah Pembayaran Anda Disini Kami Menyediakan Metode Pembayaran Bank BCA, Bank BSI, DANA & LINK AJA. <br>
					<br>
					 CS Whatsapp : 0822-4079-8083 <br>( Jam : 08.00-23.00 WIB )
				</div>
				
				<div class="col-lg-12 text-center text-md-left">
					<hr>
					<div class="">
						 © 2022 <a href="#">LonaStoreID</a>  <a href="terms.html"></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	</footer>
	<a href="https://www.instagram.com/lonastoreid/" class="btn-ig-float shadow-sm" target="_blank"><i class="fab fa-instagram" style="margin-top: 9px;"></i></a>
	<a href="https://api.whatsapp.com/send?phone=6282240798083" class="btn-call-float shadow-sm" target="_blank"><i class="fab fa-whatsapp" style="margin-top: 9px;"></i></a>
	<a href="#" id="btn-gotop" onclick="topFunction()"><i class="fas fa-angle-up mt-1"></i></a>
	<script>
mybutton = document.getElementById("btn-gotop");
window.onscroll = function() {
    scrollFunction()
};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}

function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>

</html>