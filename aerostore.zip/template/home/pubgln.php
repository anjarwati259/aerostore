<html>
<head>
<title>LonaStoreID - Top Up Games Aman, Murah, & Terpercaya</title>
<link rel="shortcut icon" href="logolona.jpeg" type="image/x-icon">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="LonaStoreID Tempat Top Up Games Yang Aman, Murah, dan Terpercaya Sejak 2017 Menyediakan Layanan Top Up Diamond Mobile Legends Dan UC PUBG Mobile Serta Jasa Joki Mobile Legends .">
<meta name="robots" content="index,nofollow">
<meta name="author" content="LonaStoreID">
<meta name="keywords" content="diamond ml murah, top up ml murah, diamond mobile legend murah, LonaStoreID">
<meta name="language" content="ID">
<meta name="coverage" content="Worldwide">
<link rel="stylesheet" href="assets\vendor\fontawesome\css\all.css">
<link rel="stylesheet" href="assets\vendor\bootstrap\css\bootstrap.min.css">
<script src="assets\js\jquery-3.5.1.min.js"></script>
<script src="assets\vendor\bootstrap\js\bootstrap.bundle.min.js"></script>
<script src="assets\vendor\alertifyjs\alertify.min.js"></script>
<link rel="stylesheet" href="assets\vendor\alertifyjs\css\alertify.min.css">
<link rel="stylesheet" href="assets\vendor\alertifyjs\css\themes\bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets\vendor\DataTables\DataTables-1.10.22\css\dataTables.bootstrap4.min.css?x">
<script type="text/javascript" src="assets\vendor\DataTables\DataTables-1.10.22\js\jquery.dataTables.min.js?x">
    </script>
<script type="text/javascript" src="assets\vendor\DataTables\DataTables-1.10.22\js\dataTables.bootstrap4.min.js?x">
    </script>
<link rel="stylesheet" href="assets\css\style.css?v=1641098465">
<script src="https://www.google.com/recaptcha/api.js" async="" defer=""></script>
</head>
<header>
<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-custom shadow-sm p-3 mb-5 bg-white">
<div class="container">
	<a class="navbar-brand" href="index.htm"><img src="logolona.jpeg" width="140px"></a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	<i class="fas fa-bars color-primary" style="font-size: 26px;"></i>
	</button>
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<div class="mr-auto"></div>
		<ul class="navbar-nav">
			<li class="nav-item">
				<li class="nav-item">
					<a class="nav-link active" href="index.htm"><i class="fas fa-home"></i> Home</a>
				</li>
				
			</ul>
		</div>
	</div>
	</nav>
	</header>
	<div class="preloader">
		<div class="loading">
			<img src="assets\images\preloader.gif" width="100"></div>
	</div>
<script>
$(document).ready(function() {
    $(".preloader").fadeOut();
})
</script>
<br>
<body class="d-flex flex-column min-vh-100">
    <br><br><br><br>
    <div class="container">
        <div class="row mt-2" style="margin:0px">
            <div class="col-md-12 col-sm-12 col-lg-4">
                <div class="text-center text-md-left mb-2">
                    <img src="pubgln.png" class="img-responsive rounded mb-2" width="200px" height="200px">
                </div>
                <h5>PUBG Mobile All Region</h5>
                <span class="strip-primary"></span>
                <p class="mt-4 pr-4"><h6>Layanan Aktif Pada 10.00 - 22.00 WIB</h6> <span class="strip-primary"></span>
                <p class="mt-4 pr-4"><h6>(Nominal 6000 UC Ke Atas Tutup Jam 18.45)</h6><center><font size="4" color="#587cc7"><b></b></font></center>
<ol>
<li>Masukkan <b>UserID</b></li>
<li>Masukkan <b>NickName</b></li>
<li>Masukkan <b>Sisa UC</b></li>
<li>Pilih <b>Nominal UC</b></li>
<li>Pilih Metode Pembayaran</li>
<li>Masukan Nomor <b>WhatsApp </b>Kamu</li>
<li>Klik <b>Beli Sekarang</b> & Lakukan <b>Pembayaran</b></li>
<li>Tunggu 15-60 Menit UC Akan Masuk Otomatis Di Akun Anda</li></ol>

<center><font size="4" color="#f33300"><b>Estimasi Proses Otomatis 15 - 60 Menit</b></font></center>
<!DOCTYPE html>
<html>
<head>
<title> TEKS BERJALAN </title>
</head>
<body>
<marquee><font size="4" color="#f33300"><b>Jika Event Maximal 360 Menit</b></font></marquee>
<body>
<html>
<hr><center><strong>
<font size="4" color="#f33300">Mengalami Kendala Top Up? </font>
<br>
<br>
 <p>Hubungi Whatsapp Kami</p>
 <br>

</strong></center><hr>
            </html></body></body></html></div>
            <div class="col-md-12 col-sm-12 col-lg-8">
			
			<form action="confirm3.php" method="POST">
			
               
                    <div class="row">
                    	                        
<div class="col-12 mb-3">
	<div class="card">
		<div class="card-body">
		<div class="pt-1 text-white text-center position-absolute circle-primary">1</div>
		<h5 class="ml-5 mt-1">Lengkapi Data</h5>
		
			<input name="layanan" type="hidden" value="PUBG Mobile All Region"/>
			<input name="serverid" type="hidden" value="0"/>
			
		
			<div class="form-row mt-4">
				<div class="col">
					<input type="number" class="form-control" name="data" placeholder="Masukan UserID" required="">
				</div>
				<div class="col">
					<input type="text" class="form-control" name="nickname" placeholder="Masukan Nickname" required="">
				</div>
				<div class="col">
					<input type="number" class="form-control" name="sisauc" placeholder="Masukan Sisa UC" required="">
				</div>
			</div>
			<div class="mt-3">
				<button type="button" class="btn btn-original btn-sm" data-toggle="modal" data-target="#exampleModal">Petunjuk</button>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="pt-2 pr-3">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<img class="img-fluid" src="assets\images\1603588464.png">
				</div>
			</div>
		</div>
	</div>
</div>
                        <div id="note"></div>
                        <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    
                                <div class="pt-1 text-white text-center position-absolute circle-primary">2</div>
                                    <h5 class="ml-5 mt-1">Pilih Nominal</h5>
                                    <div class="mt-4">
                                        <div class="panel-topup">
                                            <input type="radio" id="service0" name="service" value="690 UC Rp 157.000"><label for="service0">690 UC<br>Rp 157.000</label>
											<input type="radio" id="service1" name="service" value="1875 UC Rp 390.000"><label for="service1">1875 UC<br>Rp 390.000</label>
											<input type="radio" id="service2" name="service" value="4000 UC Rp 700.000"><label for="service2">4000 UC<br>Rp 700.000</label>
											<input type="radio" id="service3" name="service" value="8100 UC Rp1.370.000"><label for="service3">8100 UC<br>Rp1.370.000</label>
											<input type="radio" id="service4" name="service" value="8400 UC Rp1.390.000"><label for="service4">8400 UC<br>Rp1.390.000</label>
											<input type="radio" id="service5" name="service" value="10200 UC Rp1.800.000"><label for="service5">10200 UC<br>Rp1.800.000</label>
											<input type="radio" id="service6" name="service" value="16200 UC Rp2.700.000"><label for="service6">16200 UC<br>Rp2.700.000</label>
											<input type="radio" id="service7" name="service" value="16800 UC Rp2.780.000"><label for="service7">16800 UC<br>Rp2.780.000</label>
											<input type="radio" id="service8" name="service" value="24300 UC Rp3.950.000"><label for="service8">24300 UC<br>Rp3.950.000</label>
											<input type="radio" id="service9" name="service" value="25200 UC Rp4.190.000"><label for="service9">25200 UC<br>Rp4.190.000</label>
											<input type="radio" id="service10" name="service" value="32400 UC Rp5.100.000"><label for="service10">32400 UC<br>Rp5.100.000</label>
											<input type="radio" id="service11" name="service" value="33600 UC Rp5.520.000"><label for="service11">33600 UC<br>Rp5.520.000</label>
											<input type="radio" id="service12" name="service" value="42000 UC Rp6.950.000"><label for="service12">42000 UC<br>Rp6.950.000</label>
											<input type="radio" id="service13" name="service" value="50400 UC Rp8.000.000"><label for="service13">50400 UC<br>Rp8.000.000</label>
											<input type="radio" id="service14" name="service" value="58800 UC Rp9.610.000"><label for="service14">58800 UC<br>Rp9.610.000</label>
											<input type="radio" id="service15" name="service" value="67200 UC Rp10.920.000"><label for="service15">67200 UC<br>Rp10.920.000</label>
											<input type="radio" id="service16" name="service" value="84000 UC Rp13.600.000"><label for="service16">84000 UC<br>Rp13.600.000</label>
											<input type="radio" id="service17" name="service" value="109200 UC Rp17.790.000"><label for="service17">109200 UC<br>Rp17.790.000</label>
											
											
	 
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <div class="pt-1 text-white text-center position-absolute circle-primary">3</div>
                                    <h5 class="ml-5 mt-1">Pilih Metode Pembayaran</h5>
                                    <div class="mt-4">
                                        <div class="methods">
                                            <input class="mtdbtn" type="radio" id="method0" name="method" value="BCA 8305432861 a/n YULIANA">
    <label class="mtdlabel" for="method0"><img src="bca.png" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="TRANSFER_BANK_BCA"></span>
        </p>
    </label><input class="mtdbtn" type="radio" id="method1" name="method" value="BSI 1136092548 a/n YULIANA">
    <label class="mtdlabel" for="method1"><img src="bsi.jpg" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="TRANSFER_BANK_BSI"></span>
        </p>
    </label><input class="mtdbtn" type="radio" id="method2" name="method" value="DANA 082240798083 a/n YULIANA">
    <label class="mtdlabel" for="method2"><img src="dana.png" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="TRANSFER_BANK_BNI"></span>
        </p>
    </label><input class="mtdbtn" type="radio" id="method3" name="method" value="LINK AJA 082240798083 a/n YULIANA">
    <label class="mtdlabel" for="method3"><img src="linkaja.png" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="QRIS"></span>
        </p>
    </label>                                   </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                <div class="pt-1 text-white text-center position-absolute circle-primary">4</div>
                                    <h5 class="ml-5 mt-1">Masukan Nomor Whatsapp</h5>
                                    <div class="mt-4">
                                        <input type="number" class="form-control" name="nohp" placeholder="08xxxxxxxxx" required="">
                                    </div>
                                </div>
                            </div>
							<div class="card">
                                <div class="card-body">
                                <div class="pt-1 text-white text-center position-absolute circle-primary">5</div>
                                    
                                    <div class="mt-4">
									    <center>
                                        <input type="submit" value="TEKAN ORDER SEKARANG" >
										</center>
                                    </div>
                                </div>
                            </div>
                        </div>
						
						
                        
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

<br>
<footer class="footer mt-auto">
	<div class="container pt-md-3 pb-md-3 text-left text-md-left">
		<div class="row">
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-gamepad mb-2"></i></h1>
				<h5>PILIH GAME</h5>
				 Tersedia beberapa game pilihan seperti Mobile Legends dan PUBG Mobile.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-hand-pointer mb-2"></i></h1>
				<h5>PILIH NOMINAL</h5>
				 Pilih nominal topup game yang kamu pilih yang tersedia pada form order web.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-money-bill-wave mb-2"></i></h1>
				<h5>LAKUKAN PEMBAYARAN</h5>
				 Tersedia berbagai metode pembayaran diantaranya Bank BCA, Bank BSI, DANA & LINK AJA
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-gift mb-2"></i></h1>
				<h5>TOPUP BERHASIL</h5>
				 Topup akan diproses segera setelah pembayaran & konfirmasi pembayaran sudah dilakukan
			</div>
		</div>
	</div>
	<div class="footer-copyright py-3">
		<div class="container mt-2">
			<div class="row">
				<div class="col-lg-6 mb-3">
					<h4 class="mt-2 mb-3">LonaStoreID</h4>
					 LonaStoreID Adalah Tempat Top Up Games Yang Aman, Murah, dan Terpercaya. LonaStoreID Menyediakan Layanan Top Up Games seperti Diamond Mobile Legends Dan UC PUBG Mobile. Untuk Mempermudah Pembayaran Anda Disini Kami Menyediakan Metode Pembayaran Bank BCA, Bank BSI, DANA & LINK AJA. <br>
					<br>
					 CS Whatsapp : 0822-4079-8083 <br>( Jam : 08.00-23.00 WIB )
				</div>
				
				<div class="col-lg-12 text-center text-md-left">
					<hr>
					<div class="">
						 © 2022 <a href="#">LonaStoreID</a>  <a href="terms.html"></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	</footer>
	<a href="https://www.instagram.com/lonastoreid/" class="btn-ig-float shadow-sm" target="_blank"><i class="fab fa-instagram" style="margin-top: 9px;"></i></a>
	<a href="https://api.whatsapp.com/send?phone=6282240798083" class="btn-call-float shadow-sm" target="_blank"><i class="fab fa-whatsapp" style="margin-top: 9px;"></i></a>
	<a href="#" id="btn-gotop" onclick="topFunction()"><i class="fas fa-angle-up mt-1"></i></a>
	<script>
mybutton = document.getElementById("btn-gotop");
window.onscroll = function() {
    scrollFunction()
};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}

function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>

</html>