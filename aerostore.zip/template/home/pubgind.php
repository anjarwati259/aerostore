<html>
<head>
<title>LonaStoreID - Top Up Games Aman, Murah, & Terpercaya</title>
<link rel="shortcut icon" href="logolona.jpeg" type="image/x-icon">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="LonaStoreID Tempat Top Up Games Yang Aman, Murah, dan Terpercaya Sejak 2017 Menyediakan Layanan Top Up Diamond Mobile Legends Dan UC PUBG Mobile Serta Jasa Joki Mobile Legends .">
<meta name="robots" content="index,nofollow">
<meta name="author" content="LonaStoreID">
<meta name="keywords" content="diamond ml murah, top up ml murah, diamond mobile legend murah, LonaStoreID">
<meta name="language" content="ID">
<meta name="coverage" content="Worldwide">
<link rel="stylesheet" href="assets\vendor\fontawesome\css\all.css">
<link rel="stylesheet" href="assets\vendor\bootstrap\css\bootstrap.min.css">
<script src="assets\js\jquery-3.5.1.min.js"></script>
<script src="assets\vendor\bootstrap\js\bootstrap.bundle.min.js"></script>
<script src="assets\vendor\alertifyjs\alertify.min.js"></script>
<link rel="stylesheet" href="assets\vendor\alertifyjs\css\alertify.min.css">
<link rel="stylesheet" href="assets\vendor\alertifyjs\css\themes\bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets\vendor\DataTables\DataTables-1.10.22\css\dataTables.bootstrap4.min.css?x">
<script type="text/javascript" src="assets\vendor\DataTables\DataTables-1.10.22\js\jquery.dataTables.min.js?x">
    </script>
<script type="text/javascript" src="assets\vendor\DataTables\DataTables-1.10.22\js\dataTables.bootstrap4.min.js?x">
    </script>
<link rel="stylesheet" href="assets\css\style.css?v=1641098465">
<script src="https://www.google.com/recaptcha/api.js" async="" defer=""></script>
</head>
<header>
<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-custom shadow-sm p-3 mb-5 bg-white">
<div class="container">
	<a class="navbar-brand" href="index.htm"><img src="logolona.jpeg" width="140px"></a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	<i class="fas fa-bars color-primary" style="font-size: 26px;"></i>
	</button>
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<div class="mr-auto"></div>
		<ul class="navbar-nav">
			<li class="nav-item">
				<li class="nav-item">
					<a class="nav-link active" href="index.htm"><i class="fas fa-home"></i> Home</a>
				</li>
				
			</ul>
		</div>
	</div>
	</nav>
	</header>
	<div class="preloader">
		<div class="loading">
			<img src="assets\images\preloader.gif" width="100"></div>
	</div>
<script>
$(document).ready(function() {
    $(".preloader").fadeOut();
})
</script>
<br>
<body class="d-flex flex-column min-vh-100">
    <br><br><br><br>
    <div class="container">
        <div class="row mt-2" style="margin:0px">
            <div class="col-md-12 col-sm-12 col-lg-4">
                <div class="text-center text-md-left mb-2">
                    <img src="pubgind.png" class="img-responsive rounded mb-2" width="200px" height="200px">
                </div>
                <h5>PUBG Mobile Region Indonesia</h5>
                <span class="strip-primary"></span>
                <p class="mt-4 pr-4"><h6>Layanan Aktif Pada 10.00 - 22.00 WIB</h6> <span class="strip-primary"></span>
                <p class="mt-4 pr-4"><h6>(Nominal 6000 UC Ke Atas Tutup Jam 18.45)</h6><center><font size="4" color="#587cc7"><b></b></font></center>
<ol>
<li>Masukkan <b>UserID</b></li>
<li>Masukkan <b>NickName</b></li>
<li>Masukkan <b>Sisa UC</b></li>
<li>Pilih <b>Nominal UC</b></li>
<li>Pilih Metode Pembayaran</li>
<li>Masukan Nomor <b>WhatsApp </b>Kamu</li>
<li>Klik <b>Beli Sekarang</b> & Lakukan <b>Pembayaran</b></li>
<li>Tunggu 15-60 Menit UC Akan Masuk Otomatis Di Akun Anda</li></ol>

<center><font size="4" color="#f33300"><b>Estimasi Proses Otomatis 15 - 60 Menit</b></font></center>
<!DOCTYPE html>
<html>
<head>
<title> TEKS BERJALAN </title>
</head>
<body>
<marquee><font size="4" color="#f33300"><b>Jika Event Maximal 360 Menit</b></font></marquee>
<body>
<html>
<hr><center><strong>
<font size="4" color="#f33300">Mengalami Kendala Top Up? </font>
<br>
<br>
 <p>Hubungi Whatsapp Kami</p>
 <br>

</strong></center><hr>
            </html></body></body></html></div>
            <div class="col-md-12 col-sm-12 col-lg-8">
			
			<form action="confirm3.php" method="POST">
			
               
                    <div class="row">
                    	                        
<div class="col-12 mb-3">
	<div class="card">
		<div class="card-body">
		<div class="pt-1 text-white text-center position-absolute circle-primary">1</div>
		<h5 class="ml-5 mt-1">Lengkapi Data</h5>
		
			<input name="layanan" type="hidden" value="PUBG Mobile Indonesia"/>
			<input name="serverid" type="hidden" value="0"/>
			
		
			<div class="form-row mt-4">
				<div class="col">
					<input type="number" class="form-control" name="data" placeholder="Masukan UserID" required="">
				</div>
				<div class="col">
					<input type="text" class="form-control" name="nickname" placeholder="Masukan Nickname" required="">
				</div>
				<div class="col">
					<input type="number" class="form-control" name="sisauc" placeholder="Masukan Sisa UC" required="">
				</div>
			</div>
			<div class="mt-3">
				<button type="button" class="btn btn-original btn-sm" data-toggle="modal" data-target="#exampleModal">Petunjuk</button>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="pt-2 pr-3">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<img class="img-fluid" src="assets\images\1603588464.png">
				</div>
			</div>
		</div>
	</div>
</div>
                        <div id="note"></div>
                        <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    
                                <div class="pt-1 text-white text-center position-absolute circle-primary">2</div>
                                    <h5 class="ml-5 mt-1">Pilih Nominal</h5>
                                    <div class="mt-4">
                                        <div class="panel-topup">
                                            <input type="radio" id="service0" name="service" value="208 UC Rp 38.000"><label for="service0">208 UC<br>Rp 38.000</label>
											<input type="radio" id="service1" name="service" value="263 UC Rp 48.000"><label for="service1">263 UC<br>Rp 48.000</label>
											<input type="radio" id="service2" name="service" value="315 UC Rp 58.000"><label for="service2">315 UC<br>Rp 58.000</label>
											<input type="radio" id="service3" name="service" value="419 UC Rp 85.000"><label for="service3">419 UC<br>Rp 85.000</label>
											<input type="radio" id="service4" name="service" value="525 UC Rp 95.000"><label for="service4">525 UC<br>Rp 95.000</label>
											<input type="radio" id="service5" name="service" value="629 UC Rp 115.000"><label for="service5">629 UC<br>Rp 115.000</label>
											<input type="radio" id="service6" name="service" value="788 UC Rp 140.000"><label for="service6">788 UC<br>Rp 140.000</label>
											<input type="radio" id="service7" name="service" value="825 UC Rp 145.000"><label for="service7">825 UC<br>Rp 145.000</label>
											<input type="radio" id="service8" name="service" value="1050 UC Rp 185.000"><label for="service8">1050 UC<br>Rp 185.000</label>
											<input type="radio" id="service9" name="service" value="1100 UC Rp 190.000"><label for="service9">1100 UC<br>Rp 190.000</label>
											<input type="radio" id="service10" name="service" value="1204 UC Rp 210.000"><label for="service10">1204 UC<br>Rp 210.000</label>
											<input type="radio" id="service11" name="service" value="1375 UC Rp 235.000"><label for="service11">1375 UC<br>Rp 235.000</label>
											<input type="radio" id="service12" name="service" value="1638 UC Rp 275.000"><label for="service12">1638 UC<br>Rp 275.000</label>
											<input type="radio" id="service13" name="service" value="1900 UC Rp 315.000"><label for="service13">1900 UC<br>Rp 315.000</label>
											<input type="radio" id="service14" name="service" value="1925 UC Rp 320.000"><label for="service14">1925 UC<br>Rp 320.000</label>
											<input type="radio" id="service15" name="service" value="2163 UC Rp 370.000"><label for="service15">2163 UC<br>Rp 370.000</label>
											
											
											<input type="radio" id="service16" name="service" value="2200 UC Rp 360.000"><label for="service16">2200 UC<br>Rp 360.000</label>
											<input type="radio" id="service17" name="service" value="2425 UC Rp 384.000"><label for="service17">2425 UC<br>Rp 384.000</label>
											<input type="radio" id="service18" name="service" value="2875 UC Rp 455.000"><label for="service18">2875 UC<br>Rp 455.000</label>
											<input type="radio" id="service19" name="service" value="3138 UC Rp 495.000"><label for="service19">3138 UC<br>Rp 495.000</label>
											<input type="radio" id="service20" name="service" value="3400 UC Rp 540.000"><label for="service20">3400 UC<br>Rp 540.000</label>
											<input type="radio" id="service21" name="service" value="3925 UC Rp 640.000"><label for="service21">3925 UC<br>Rp 640.000</label>
											<input type="radio" id="service22" name="service" value="4250 UC Rp 680.000"><label for="service22">4250 UC<br>Rp 680.000</label>
											<input type="radio" id="service23" name="service" value="4775 UC Rp 750.000"><label for="service23">4775 UC<br>Rp 750.000</label>
											<input type="radio" id="service24" name="service" value="5558 UC Rp 870.000"><label for="service24">5558 UC<br>Rp 870.000</label>
											<input type="radio" id="service25" name="service" value="6000 UC Rp 900.000"><label for="service25">6000 UC<br>Rp 900.000</label>
											<input type="radio" id="service26" name="service" value="6629 UC Rp1.030.000"><label for="service26">6629 UC<br>Rp1.030.000</label>
											<input type="radio" id="service27" name="service" value="7050 UC Rp1.080.000"><label for="service27">7050 UC<br>Rp1.080.000</label>
											<input type="radio" id="service28" name="service" value="7375 UC Rp1.130.000"><label for="service28">7375 UC<br>Rp1.130.000</label>
											<input type="radio" id="service29" name="service" value="7638 UC Rp1.170.000"><label for="service29">7638 UC<br>Rp1.170.000</label>
											
											<input type="radio" id="service30" name="service" value="8425 UC Rp1.350.000"><label for="service30">8425 UC<br>Rp1.350.000</label>
											<input type="radio" id="service31" name="service" value="8875 UC Rp1.380.800"><label for="service31">8875 UC<br>Rp1.380.800</label>
											<input type="radio" id="service32" name="service" value="9375 UC Rp1.410.000"><label for="service32">9375 UC<br>Rp1.410.000</label>
											<input type="radio" id="service33" name="service" value="10006 UC Rp1.430.000"><label for="service33">10006 UC<br>Rp1.430.000</label>
											<input type="radio" id="service34" name="service" value="10163 UC Rp1.450.000"><label for="service34">10163 UC<br>Rp1.450.000</label>
											<input type="radio" id="service35" name="service" value="11013 UC Rp1.576.000"><label for="service35">11013 UC<br>Rp1.576.000</label>
											<input type="radio" id="service36" name="service" value="11800 UC Rp1.725.000"><label for="service36">11800 UC<br>Rp1.725.000</label>
											<input type="radio" id="service37" name="service" value="13300 UC Rp1.925.000"><label for="service37">13300 UC<br>Rp1.925.0000</label>
											<input type="radio" id="service38" name="service" value="15375 UC Rp2.190.000"><label for="service38">15375 UC<br>Rp2.190.000</label>
											<input type="radio" id="service39" name="service" value="16750 UC Rp2.406.000"><label for="service39">16750 UC<br>Rp2.406.000</label>
											<input type="radio" id="service40" name="service" value="17013 UC Rp2.445.000"><label for="service40">17013 UC<br>Rp2.445.000</label>
											<input type="radio" id="service41" name="service" value="18750 UC Rp2.605.000"><label for="service41">18750 UC<br>Rp2.605.000</label>
											<input type="radio" id="service42" name="service" value="20125 UC Rp2.810.000"><label for="service42">20125 UC<br>Rp2.810.000</label>
											<input type="radio" id="service43" name="service" value="20326 UC Rp2.892.000"><label for="service43">20326 UC<br>Rp2.892.000</label>
											<input type="radio" id="service44" name="service" value="21625 UC Rp3.100.000"><label for="service44">21625 UC<br>Rp3.100.000</label>
											
											<input type="radio" id="service45" name="service" value="30025 UC Rp4.230.000"><label for="service45">30025 UC<br>Rp4.230.000</label>
											<input type="radio" id="service46" name="service" value="30489 UC Rp1.380.000"><label for="service46">30489 UC<br>Rp1.380.000</label>
											<input type="radio" id="service47" name="service" value="40024 UC Rp5.570.000"><label for="service47">40024 UC<br>Rp5.570.000</label>
											<input type="radio" id="service48" name="service" value="46875 UC Rp6.530.000"><label for="service48">46875 UC<br>Rp6.530.000</label>
											<input type="radio" id="service49" name="service" value="50013 UC Rp7.100.000"><label for="service49">50013 UC<br>Rp7.100.000</label>
											<input type="radio" id="service50" name="service" value="50030 UC Rp7.120.000"><label for="service50">50030 UC<br>Rp7.120.000</label>
											<input type="radio" id="service51" name="service" value="56250 UC Rp7.760.000"><label for="service51">56250 UC<br>Rp7.760.000</label>
											
											<input type="radio" id="service52" name="service" value="65625 UC Rp9.100.000"><label for="service52">65625 UC<br>Rp9.100.000</label>
											<input type="radio" id="service53" name="service" value="70000 UC Rp9.730.000"><label for="service53">70000 UC<br>Rp9.730.000</label>
											<input type="radio" id="service54" name="service" value="75000 UC Rp10.370.000"><label for="service54">75000 UC<br>10.370.000</label>
											<input type="radio" id="service55" name="service" value="80038 UC Rp11.100.000"><label for="service55">80038 UC<br>Rp11.100.000</label>
											<input type="radio" id="service56" name="service" value="90000 UC Rp12.600.000"><label for="service56">90000 UC<br>Rp12.600.000</label>
											<input type="radio" id="service57" name="service" value="93750 UC Rp13.650.000"><label for="service57">93750 UC<br>Rp13.650.000</label>
											<input type="radio" id="service58" name="service" value="100000 UC Rp14.350.000"><label for="service58">100000 UC<br>Rp14.350.000</label>
											
	 
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <div class="pt-1 text-white text-center position-absolute circle-primary">3</div>
                                    <h5 class="ml-5 mt-1">Pilih Metode Pembayaran</h5>
                                    <div class="mt-4">
                                        <div class="methods">
                                            <input class="mtdbtn" type="radio" id="method0" name="method" value="BCA 8305432861 a/n YULIANA">
    <label class="mtdlabel" for="method0"><img src="bca.png" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="TRANSFER_BANK_BCA"></span>
        </p>
    </label><input class="mtdbtn" type="radio" id="method1" name="method" value="BSI 1136092548 a/n YULIANA">
    <label class="mtdlabel" for="method1"><img src="bsi.jpg" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="TRANSFER_BANK_BSI"></span>
        </p>
    </label><input class="mtdbtn" type="radio" id="method2" name="method" value="DANA 082240798083 a/n YULIANA">
    <label class="mtdlabel" for="method2"><img src="dana.png" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="TRANSFER_BANK_BNI"></span>
        </p>
    </label><input class="mtdbtn" type="radio" id="method3" name="method" value="LINK AJA 082240798083 a/n YULIANA">
    <label class="mtdlabel" for="method3"><img src="linkaja.png" width="180" height="90" class="img-fluid">
    <p class="float-right">
            <span class="badge badge-success" id="QRIS"></span>
        </p>
    </label>                                   </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 mb-3">
                            <div class="card">
                                <div class="card-body">
                                <div class="pt-1 text-white text-center position-absolute circle-primary">4</div>
                                    <h5 class="ml-5 mt-1">Masukan Nomor Whatsapp</h5>
                                    <div class="mt-4">
                                        <input type="number" class="form-control" name="nohp" placeholder="08xxxxxxxxx" required="">
                                    </div>
                                </div>
                            </div>
							<div class="card">
                                <div class="card-body">
                                <div class="pt-1 text-white text-center position-absolute circle-primary">5</div>
                                    
                                    <div class="mt-4">
									    <center>
                                        <input type="submit" value="TEKAN ORDER SEKARANG" >
										</center>
                                    </div>
                                </div>
                            </div>
                        </div>
						
						
                        
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

<br>
<footer class="footer mt-auto">
	<div class="container pt-md-3 pb-md-3 text-left text-md-left">
		<div class="row">
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-gamepad mb-2"></i></h1>
				<h5>PILIH GAME</h5>
				 Tersedia beberapa game pilihan seperti Mobile Legends dan PUBG Mobile.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-hand-pointer mb-2"></i></h1>
				<h5>PILIH NOMINAL</h5>
				 Pilih nominal topup game yang kamu pilih yang tersedia pada form order web.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-money-bill-wave mb-2"></i></h1>
				<h5>LAKUKAN PEMBAYARAN</h5>
				 Tersedia berbagai metode pembayaran diantaranya Bank BCA, Bank BSI, DANA & LINK AJA
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-gift mb-2"></i></h1>
				<h5>TOPUP BERHASIL</h5>
				 Topup akan diproses segera setelah pembayaran & konfirmasi pembayaran sudah dilakukan
			</div>
		</div>
	</div>
	<div class="footer-copyright py-3">
		<div class="container mt-2">
			<div class="row">
				<div class="col-lg-6 mb-3">
					<h4 class="mt-2 mb-3">LonaStoreID</h4>
					 LonaStoreID Adalah Tempat Top Up Games Yang Aman, Murah, dan Terpercaya. LonaStoreID Menyediakan Layanan Top Up Games seperti Diamond Mobile Legends Dan UC PUBG Mobile. Untuk Mempermudah Pembayaran Anda Disini Kami Menyediakan Metode Pembayaran Bank BCA, Bank BSI, DANA & LINK AJA. <br>
					<br>
					 CS Whatsapp : 0822-4079-8083 <br>( Jam : 08.00-23.00 WIB )
				</div>
				
				<div class="col-lg-12 text-center text-md-left">
					<hr>
					<div class="">
						 © 2022 <a href="#">LonaStoreID</a>  <a href="terms.html"></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	</footer>
	<a href="https://www.instagram.com/lonastoreid/" class="btn-ig-float shadow-sm" target="_blank"><i class="fab fa-instagram" style="margin-top: 9px;"></i></a>
	<a href="https://api.whatsapp.com/send?phone=6282240798083" class="btn-call-float shadow-sm" target="_blank"><i class="fab fa-whatsapp" style="margin-top: 9px;"></i></a>
	<a href="#" id="btn-gotop" onclick="topFunction()"><i class="fas fa-angle-up mt-1"></i></a>
	<script>
mybutton = document.getElementById("btn-gotop");
window.onscroll = function() {
    scrollFunction()
};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}

function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>

</html>