<html>
<head>
<title>AEROSTORE - Top Up Games Aman, Murah, & Terpercaya</title>
<link rel="shortcut icon" href="aero1.ico" type="image/x-icon">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="AEROSTORE Tempat Top Up Games Yang Aman, Murah, dan Terpercaya Sejak 2017 Menyediakan Layanan Top Up Diamond Mobile Legends Dan UC PUBG Mobile Serta Jasa Joki Mobile Legends .">
<meta name="robots" content="index,nofollow">
<meta name="author" content="AEROSTORE">
<meta name="keywords" content="diamond ml murah, top up ml murah, diamond mobile legend murah, AEROSTORE">
<meta name="language" content="ID">
<meta name="coverage" content="Worldwide">
<link rel="stylesheet" href="assets\vendor\fontawesome\css\all.css">
<link rel="stylesheet" href="assets\vendor\bootstrap\css\bootstrap.min.css">
<script src="assets\js\jquery-3.5.1.min.js"></script>
<script src="assets\vendor\bootstrap\js\bootstrap.bundle.min.js"></script>
<script src="assets\vendor\alertifyjs\alertify.min.js"></script>
<link rel="stylesheet" href="assets\vendor\alertifyjs\css\alertify.min.css">
<link rel="stylesheet" href="assets\vendor\alertifyjs\css\themes\bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets\vendor\DataTables\DataTables-1.10.22\css\dataTables.bootstrap4.min.css?x">
<script type="text/javascript" src="assets\vendor\DataTables\DataTables-1.10.22\js\jquery.dataTables.min.js?x">
    </script>
<script type="text/javascript" src="assets\vendor\DataTables\DataTables-1.10.22\js\dataTables.bootstrap4.min.js?x">
    </script>
<link rel="stylesheet" href="assets\css\style.css?v=1641098465">
<script src="https://www.google.com/recaptcha/api.js" async="" defer=""></script>
</head>
<header>
<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-custom shadow-sm p-3 mb-5 bg-white">
<div class="container">
	<a class="navbar-brand" href="index.php"><img src="aero1.png" width="50px"></a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	<i class="fas fa-bars color-primary" style="font-size: 26px;"></i>
	</button>
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<div class="mr-auto"></div>
		<ul class="navbar-nav">
			<li class="nav-item">
				<li class="nav-item">
					<a class="nav-link active" href="index.php"><i class="fas fa-home"></i> Home</a>
				</li>
				
			</ul>
		</div>
	</div>
	</nav>
	</header>
	<div class="preloader">
		<div class="loading">
			<img src="assets\images\preloader.gif" width="100"></div>
	</div>
	<script>
$(document).ready(function() {
    $(".preloader").fadeOut();
})
	</script>
	<br>
	<body class="d-flex flex-column min-vh-100">
	<br>
	<br>
	<br>
	<br>
	<div class="container">
		<div class="row mt-2" style="margin:0px">
			<div id="slider-img" class="carousel slide" data-ride="carousel">
				<ol class="carousel-indicators">
					<li data-target="#slider-img" data-slide-to="0" class="active"></li>
				</ol>
				<div class="carousel-inner" style="border-radius: 5px;">
					<div class="carousel-item active">
						<img src="aero2.png" class="d-block w-100"></div>
				</div>
				<a class="carousel-control-prev" href="#slider-img" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#slider-img" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
		<div class="col-12 mb-3 mt-4">
			<center>
			<span class="p-2" style="font-weight: 700; font-size: 20px; border-radius: 4px; color: #001439"></span>
			</center>
		</div>
		
		<div class="container">
        <div class="row mt-2" style="margin:0px">
            <div class="col-md-12 col-sm-12 col-lg-4">
                <div class="text-center text-md-left mb-2">
                    <img src="pubgindo.png" class="img-responsive rounded mb-2" width="200px" height="200px">
                </div>
                <h5>PUBG Mobile Indonesia</h5>
                <span class="strip-primary"></span>
                <p class="mt-4 pr-4"><h6>Proses 1-180 Menit</h6><center><font size="4" color="#00BFFF"><b>Open 24 Jam</b></font></center>
<font size="4" color="black"><b> Cara Order : </b>
<br>
1. Masukan ID  <br/>
2. Pilih nominal UC <br/>
3. Pilih Metode Pembayaran<br/>
4. Masukan Nomor WhatsApp Kamu<br/>
5. Klik Beli Sekarang & Lakukan Pembayaran<br/>
6. Tunggu 1 - 180 Menit(Maksimal 24 Jam) UC Akan Masuk Otomatis Di Akun Anda</b></font>
<br>
<br>
<center><font size="4" color="#00BFFF"><b>Estimasi Proses Otomatis 1 - 180 menit</b></font></center>
<!DOCTYPE html>
<html>
<head>
<title> TEKS BERJALAN </title>
</head>
<body>
<marquee><font size="4" color="#00BFFF"><b>Jika Event Maximal 360 Menit</b></font></marquee>
<body>
<html>
            </html></body></body></html></div>
            <div class="col-md-12 col-sm-12 col-lg-8">
				<form action="" method="post">
                   <div class="row">
                    	                        
<div class="col-12 mb-3">
<div class="card">
<div class="card-body">
<div class="text-white text-center position-absolute circle-primary">1</div><h5 style="margin-left: 40px;">Lengkapi data</h5>
			<hr><div class="form-row mt-4">
				<div class="col">
					<input type="number" class="form-control" name="data" placeholder="Masukan UserID" required="">
				</div>
				<div class="col">
					<input type="number" class="form-control" name="zoneid" placeholder="Masukan ServerID" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength="5" required="">
				</div>
			</div>
			<div class="mt-3">
				
			</div>
		</div>
	</div>
	
</div>
                        <div id="note"></div>
						
						<div class="col-12 mb-3">
                        <div class="card">
                                <div class="card-body">
                                <div class="text-white text-center position-absolute circle-primary">2</div>
                                <h5 style="margin-left: 40px;">Pilih nominal</h5>
                                    <hr><div class="mt-4">
                                        <div class="panel-topup">
                                            <input type="radio" id="service0" name="service" value="572"><label onclick="ganti('label_service0')" id="label_service0"  for="service0">263 UC <br>Rp 45.000</label><input type="radio" id="service1" name="service" value="573"><label onclick="ganti('label_service1')" id="label_service1"  for="service1">525 UC <br>Rp 90.000</label><input type="radio" id="service2" name="service" value="574"><label onclick="ganti('label_service2')" id="label_service2"  for="service2">788 UC <br>Rp 134.000</label><input type="radio" id="service3" name="service" value="575"><label onclick="ganti('label_service3')" id="label_service3"  for="service3">1050 UC <br>Rp 178.000</label><input type="radio" id="service4" name="service" value="576"><label onclick="ganti('label_service4')" id="label_service4"  for="service4">1375 UC <br>Rp 222.000</label><input type="radio" id="service5" name="service" value="577"><label onclick="ganti('label_service5')" id="label_service5"  for="service5">1638 UC <br>Rp 266.000</label><input type="radio" id="service6" name="service" value="578"><label onclick="ganti('label_service6')" id="label_service6"  for="service6">1900 UC <br>Rp 310.000</label><input type="radio" id="service7" name="service" value="579"><label onclick="ganti('label_service7')" id="label_service7"  for="service7">2163 UC <br>Rp 354.000</label><input type="radio" id="service8" name="service" value="580"><label onclick="ganti('label_service8')" id="label_service8"  for="service8">2425 UC <br>Rp 398.000</label><input type="radio" id="service9" name="service" value="581"><label onclick="ganti('label_service9')" id="label_service9"  for="service9">2875 UC <br>Rp 442.000</label><input type="radio" id="service10" name="service" value="582"><label onclick="ganti('label_service10')" id="label_service10"  for="service10">3138 UC <br>Rp 486.000</label><input type="radio" id="service11" name="service" value="583"><label onclick="ganti('label_service11')" id="label_service11"  for="service11">3400 UC <br>Rp 530.000</label><input type="radio" id="service12" name="service" value="584"><label onclick="ganti('label_service12')" id="label_service12"  for="service12">3925 UC <br>Rp 618.000</label><input type="radio" id="service13" name="service" value="585"><label onclick="ganti('label_service13')" id="label_service13"  for="service13">4250 UC <br>Rp 662.000</label><input type="radio" id="service14" name="service" value="586"><label onclick="ganti('label_service14')" id="label_service14"  for="service14">6000 UC <br>Rp 882.000</label>   <input type="radio" id="service14" name="service" value="586"><label onclick="ganti('label_service14')" id="label_service14"  for="service14">9375 UC <br>Rp 1.322.000</label><input type="radio" id="service14" name="service" value="586"><label onclick="ganti('label_service14')" id="label_service14"  for="service14">46875 UC <br>Rp 6.605.000</label><input type="radio" id="service14" name="service" value="586"><label onclick="ganti('label_service14')" id="label_service14"  for="service14">93750 UC <br>Rp 13.210.000</label>                                     </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						
                                                <div class="col-12 mb-3">
                        
                         </div>
                        
                        
                        <div class="col-12 mb-3">
							 <button type="submit"><b>BELI SEKARANG</b></button> 
                           
                        </div>
                        <div id="ordermodal" class="modal fade" tabindex="-1" role="dialog">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <div id="orderdetail"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
		
		
		
	</div>
	</body>
	
	<script>
		var demoImage = '1645470336.png';
	</script>
	<script src="promobox.js"></script>
	
	<div class="container container-1440">
    <div class="px-lg-3 pt-3">
      <div class="row">
        <div class="col-12">
          <div class="caption-group caption-group caption-group-lg-left">
            <div class="sub-caption">Dukungan Pelanggan</div>

            <div class="caption">
              <h2>Hubungi kami</h2>
            </div>
          </div>

          <div class="home-cs-container mt-3">
              <!--            <a class="home-cs-card" href="https://m.me/kioskutopup" target="_blank" rel="noreferrer">-->
              <!--  <div class="cs-image">-->
              <!--    <img alt="" src="cs-messenger.svg">-->
              <!--  </div>-->
              <!--  <div class="cs-caption">Messenger</div>-->
              <!--</a>-->
            
            

            
            

                                                                <a class="home-cs-card" href="http://wa.me/6282234963134" target="_blank">
                      <div class="cs-image">
                          <img alt="" src="wa.svg">
                      </div>
                      <div class="cs-caption"></div>
                    </a>
             
                                            
       
          </div>
        </div>
      </div>
    </div>
  </div>
	
	
	<script>var demoImage = '';</script>
	<script src="assets\js\promobox.js"></script>
	<br>
	<footer class="footer mt-auto">
	<div class="container pt-md-3 pb-md-3 text-left text-md-left">
		<div class="row">
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-gamepad mb-2"></i></h1>
				<h5>PILIH GAME</h5>
				 Tersedia beberapa game pilihan seperti Mobile Legends dan PUBG Mobile.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-hand-pointer mb-2"></i></h1>
				<h5>PILIH NOMINAL</h5>
				 Pilih nominal topup game yang kamu pilih yang tersedia pada form order web.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-money-bill-wave mb-2"></i></h1>
				<h5>LAKUKAN PEMBAYARAN</h5>
				 Tersedia berbagai metode pembayaran diantaranya Alfamart, Bank BCA, Bank Mandiri, Bank BNI, Bank Bri, DANA, OVO, Gopay, Shopee Pay, Link Aja, dll.
			</div>
			<div class="col-md-3 col-lg-3 col-sm-12 mt-md-0 mt-3 p-3 text-center footer-tutorial">
				<h1><i class="fas fa-gift mb-2"></i></h1>
				<h5>TOPUP BERHASIL</h5>
				 Topup akan diproses segera setelah pembayaran & konfirmasi pembayaran sudah dilakukan
			</div>
		</div>
	</div>
	<div class="footer-copyright py-3">
		<div class="container mt-2">
			<div class="row">
				
				
				<div class="col-lg-12 text-center text-md-left">
					<hr>
					<div class="">
						 © 2022 <a href="#">AEROSTORE</a>  <a href="terms.html"></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	</footer>
	<a href="https://www.instagram.com/aero_store1/" class="btn-ig-float shadow-sm" target="_blank"><i class="fab fa-instagram" style="margin-top: 9px;"></i></a>
	<a href="https://api.whatsapp.com/send?phone=6282234963134" class="btn-call-float shadow-sm" target="_blank"><i class="fab fa-whatsapp" style="margin-top: 9px;"></i></a>
	<a href="#" id="btn-gotop" onclick="topFunction()"><i class="fas fa-angle-up mt-1"></i></a>
	<script>
mybutton = document.getElementById("btn-gotop");
window.onscroll = function() {
    scrollFunction()
};
function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
	</script>
	</html>