<?php
//gabungkan semua bagian layout menjadi satu
require_once('head.php');
require_once('content.php');
require_once('footer.php');