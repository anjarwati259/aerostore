<html>
<head>
<title>AEROSTORE - Top Up Games Aman, Murah, & Terpercaya</title>
<link rel="shortcut icon" href="<?php echo base_url() ?>/template/home/aero1.ico" type="image/x-icon">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="AEROSTORE Tempat Top Up Games Yang Aman, Murah, dan Terpercaya Sejak 2017 Menyediakan Layanan Top Up Diamond Mobile Legends Dan UC PUBG Mobile Serta Jasa Joki Mobile Legends .">
<meta name="robots" content="index,nofollow">
<meta name="author" content="AEROSTORE">
<meta name="keywords" content="diamond ml murah, top up ml murah, diamond mobile legend murah, AEROSTORE">
<meta name="language" content="ID">
<meta name="coverage" content="Worldwide">
<link rel="stylesheet" href="<?php echo base_url() ?>/template/home/assets/vendor/fontawesome/css/all.css">
<link rel="stylesheet" href="<?php echo base_url() ?>/template/home/assets\vendor\bootstrap\css\bootstrap.min.css">
<script src="<?php echo base_url() ?>/template/home/assets\js\jquery-3.5.1.min.js"></script>
<script src="<?php echo base_url() ?>/template/home/assets\vendor\bootstrap\js\bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url() ?>/template/home/assets\vendor\alertifyjs\alertify.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url() ?>/template/home/assets\vendor\alertifyjs\css\alertify.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>/template/home/assets\vendor\alertifyjs\css\themes\bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/template/home/assets\vendor\DataTables\DataTables-1.10.22\css\dataTables.bootstrap4.min.css?x">
<script type="text/javascript" src="<?php echo base_url() ?>/template/home/assets\vendor\DataTables\DataTables-1.10.22\js\jquery.dataTables.min.js?x">
    </script>
<script type="text/javascript" src="<?php echo base_url() ?>/template/home/assets\vendor\DataTables\DataTables-1.10.22\js\dataTables.bootstrap4.min.js?x">
    </script>
<link rel="stylesheet" href="<?php echo base_url() ?>/template/home/assets\css\style.css?v=1641098465">
<script src="https://www.google.com/recaptcha/api.js" async="" defer=""></script>
</head>
<header>
<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-custom shadow-sm p-3 mb-5 bg-white">
<div class="container">
	<a class="navbar-brand" href="<?php echo base_url('home') ?>"><img src="<?php echo base_url() ?>/template/home/aero1.png" width="50px"></a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	<i class="fas fa-bars color-primary" style="font-size: 26px;"></i>
	</button>
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<div class="mr-auto"></div>
		<ul class="navbar-nav">
			<li class="nav-item">
				<li class="nav-item">
					<a class="nav-link active" href="<?php echo base_url('home') ?>"><i class="fas fa-home"></i> Home</a>
				</li>
				
			</ul>
		</div>
	</div>
	</nav>
	</header>
	<div class="preloader">
		<div class="loading">
			<img src="<?php echo base_url() ?>/template/home/assets\images\preloader.gif" width="100"></div>
	</div>
	<script>
$(document).ready(function() {
    $(".preloader").fadeOut();
})
	</script>
	<br>
	<body class="d-flex flex-column min-vh-100">
	<br>
	<br>
	<br>
	<br>

	<div class="container">