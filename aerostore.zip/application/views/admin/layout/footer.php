            </div>
        <!-- /. PAGE INNER  -->
        </div>

<!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url() ?>/template/admin/assets/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url() ?>/template/admin/assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url() ?>/template/admin/assets/js/jquery.metisMenu.js"></script>
    <!-- Custom Js -->
    <script src="<?php echo base_url() ?>/template/admin/assets/js/custom-scripts.js"></script>
    <script src="<?php echo base_url() ?>/template/admin/assets/js/toastr.min.js"></script>
    <?php include(APPPATH.'views/ajax/admin_ajax.php'); ?>
</body>

</html>